$(window).on('load', function () {
    $('.loader').fadeOut();
    $('.loader-mask').delay(350).fadeOut('slow');
});
